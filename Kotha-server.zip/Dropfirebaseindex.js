/**
 * Run this script ONCE to fix the firebaseUid duplicate key error:
 *   node scripts/dropFirebaseIndex.js
 */

require("dotenv").config();
const mongoose = require("mongoose");

async function dropIndex() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ MongoDB connected");

    const collection = mongoose.connection.collection("users");

    // Show all current indexes
    const indexes = await collection.indexes();
    console.log("\n📋 Current indexes:");
    indexes.forEach((idx) => console.log(" -", idx.name, "→", JSON.stringify(idx.key)));

    // Drop the old firebaseUid index if it exists
    const hasIndex = indexes.some((idx) => idx.name === "firebaseUid_1");
    if (hasIndex) {
      await collection.dropIndex("firebaseUid_1");
      console.log("\n🗑️  firebaseUid_1 index dropped successfully!");
    } else {
      console.log("\n⚠️  firebaseUid_1 index not found — already removed.");
    }

    // Show updated indexes
    const updatedIndexes = await collection.indexes();
    console.log("\n📋 Updated indexes:");
    updatedIndexes.forEach((idx) => console.log(" -", idx.name, "→", JSON.stringify(idx.key)));

  } catch (err) {
    console.error("❌ Error:", err.message);
  } finally {
    await mongoose.disconnect();
    console.log("\n🔌 Disconnected. Done!");
  }
}

dropIndex();